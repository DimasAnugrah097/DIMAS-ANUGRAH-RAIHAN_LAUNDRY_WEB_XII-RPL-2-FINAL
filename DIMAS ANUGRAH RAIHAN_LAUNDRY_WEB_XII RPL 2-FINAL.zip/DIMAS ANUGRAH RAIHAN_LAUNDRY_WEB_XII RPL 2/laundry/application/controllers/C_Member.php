<?php
defined('BASEPATH') or exit('No direct script access allowed');

class C_Member extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('username')) {
            redirect('C_Auth');
        }
        if ($this->session->userdata('level') == 'owner') {
            redirect('C_Laporan');
        }
    }
    public function index()
    {
        $data['judul'] = 'Laundry | Data Member';
        if ($this->session->userdata('level') == 'admin') {
            $data['member'] = $this->M_App->tampiljoin('member', 'outlet', 'id_outlet');
        } else {
            $data['member'] = $this->M_App->tampiljoin_where('member', 'outlet', 'id_outlet', ['member.id_outlet' => $this->session->userdata('id_outlet')]);
        }
        $this->load->view('layout/header__', $data);
        $this->load->view('member/index', $data);
        $this->load->view('layout/footer__');
    }
    public function formtambahmember()
    {
        $this->_tambahmember();
    }

    function _tambahmember()
    {
        $this->form_validation->set_rules('nama', 'Nama', 'trim|required', [
            'required' => 'harus diisi'
        ]);
        $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required', [
            'required' => 'harus diisi'
        ]);
        $this->form_validation->set_rules('jk', 'Jk', 'trim|required', [
            'required' => 'harus diisi'
        ]);
        $this->form_validation->set_rules('no_hp', 'No_hp', 'trim|required|numeric', [
            'required' => 'harus diisi',
            'numeric' => 'harus diisi dengan angka'
        ]);

        if ($this->form_validation->run() == FALSE) {
            $data['judul'] = 'Form Tambah Member';
            $this->load->view('layout/header__', $data);
            $this->load->view('member/formtambah', $data);
            $this->load->view('layout/footer__');
        } else {
            $nama = htmlspecialchars($this->input->post('nama', true), ENT_QUOTES);
            $alamat = htmlspecialchars($this->input->post('alamat', true), ENT_QUOTES);
            $no_hp = htmlspecialchars($this->input->post('no_hp', true), ENT_QUOTES);
            $jk = htmlspecialchars($this->input->post('jk', true), ENT_QUOTES);

            $data = [
                'id_outlet' => $this->session->userdata('id_outlet'),
                'nama' => $nama,
                'alamat' => $alamat,
                'no_hp' => $no_hp,
                'jk' => $jk
            ];
            $this->M_App->tambahdata('member', $data);
            $this->session->set_flashdata('pesan', 'Data Berhasil Ditambah');
            redirect('C_Member');
        }
    }
    public function formeditmember($id)
    {
        $this->_editmember($id);
    }
    private function _editmember($id)
    {
        $this->form_validation->set_rules('nama', 'Nama', 'trim|required', [
            'required' => 'harus diisi'
        ]);
        $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required', [
            'required' => 'harus diisi'
        ]);
        $this->form_validation->set_rules('jk', 'Jk', 'trim|required', [
            'required' => 'harus diisi'
        ]);
        $this->form_validation->set_rules('no_hp', 'No_hp', 'trim|required|numeric', [
            'required' => 'harus diisi',
            'numeric' => 'harus diisi dengan angka'
        ]);

        if ($this->form_validation->run() == FALSE) {
            $data['judul'] = 'Form Edit member';
            $data['member'] = $this->M_App->formeditdata('member', 'id_member', $id);
            if ($data['member']->id_member) {
                $this->load->view('layout/header__', $data);
                $this->load->view('member/formedit', $data);
                $this->load->view('layout/footer__');
            } else {
                $this->session->set_flashdata('pesan', 'ID Tidak Ditemukan');
                redirect('C_Member');
            }
        } else {
            $nama = htmlspecialchars($this->input->post('nama', true), ENT_QUOTES);
            $alamat = htmlspecialchars($this->input->post('alamat', true), ENT_QUOTES);
            $no_hp = htmlspecialchars($this->input->post('no_hp', true), ENT_QUOTES);
            $jk = htmlspecialchars($this->input->post('jk', true), ENT_QUOTES);

            $data = [
                'nama' => $nama,
                'alamat' => $alamat,
                'no_hp' => $no_hp,
                'jk' => $jk
            ];
            $this->M_App->editdata('member', 'id_member', $id, $data);
            $this->session->set_flashdata('pesan', 'Data Berhasil Diedit');
            redirect('C_Member');
        }
    }
    public function hapusmember($id)
    {
        $this->M_App->hapusdata('member', 'id_member', $id);
        $this->session->set_flashdata('pesan', 'Data Berhasil Dihapus');
        redirect('C_Member');
    }
}
