<div class="container">
    <h3 class="text-center mt-3"><?= $judul; ?></h3>
    <?php if ($this->session->flashdata()) : ?>
        <div class="alert alert-success mt-3">
            <?= $this->session->flashdata('pesan'); ?>
        </div>
    <?php endif ?>
    <table class="table table-bordered mt-3" id="data">
        <thead class="bg-dark text-white">
            <tr>
                <td>No</td>
                <td>Nama</td>
                <td>Alamat</td>
                <td>Telepon</td>
                <td>Aksi</td>
            </tr>
        </thead>
        <?php
        $no = 1;
        foreach ($outlet as $o) :
        ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $o->nama_outlet; ?></td>
                <td><?= $o->alamat_outlet; ?></td>
                <td><?= $o->tlp; ?></td>
                <td>
                    <a href="<?= base_url('C_Outlet/formeditoutlet/' . $o->id_outlet) ?>" class="btn btn-primary">Edit</a>
                    <a href="<?= base_url('C_Outlet/hapusoutlet/' . $o->id_outlet) ?>" onclick="return confirm('Yakin Hapus Data Outlet?')" class="btn btn-danger">Hapus</a>
                </td>
            </tr>
        <?php endforeach ?>
    </table>
    <a href="<?= base_url('C_Outlet/formtambahoutlet') ?>" class="btn btn-success mt-3 mb-3">Tambah</a>
</div>