<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Laundry | Login</title>
	<link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css') ?>">
	<link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/style.css') ?>">
</head>

<body>
	<div class="login-box">
		<div class="title">
			<h2 class="title-login">Login</h2>
		</div>
		<form action="<?= base_url('C_Auth') ?>" method="post">
			<input type="hidden" name="<?= csrf()['name'] ?>" value="<?= csrf()['hash']; ?>">
				<div class="form-group">
					<label for="username">Username <span class="text-danger">*</span></label><br>
					<input type="username" name="username" class="form-control">
					<?= form_error('username', '<div class="text-danger">', '</div>') ?>
				</div>
				<div class="form-group">
					<label for="username">Password <span class="text-danger">*</span></label><br>
					<input type="password" name="password" class="form-control">
					<?= form_error('password', '<div class="text-danger">', '</div>') ?>
				</div>
				<?php if ($this->session->flashdata()) : ?>
					<div class="alert alert-danger">
						<?= $this->session->flashdata('pesan'); ?>
					</div>
				<?php endif ?>
				<button class="btn btn-primary">Login</button>
		</form>
	</div>
</body>
</html>