<div class="container">
    <h3 class="text-center mt-3"><?= $judul; ?></h3>
    <?php if ($this->session->flashdata()) : ?>
        <div class="alert alert-success mt-3">
            <?= $this->session->flashdata('pesan'); ?>
        </div>
    <?php endif ?>
    <table class="table table-bordered" id="data">
        <thead class="bg-dark text-white">
            <tr>
                <td>No</td>
                <td>Nama</td>
                <td>Jenis</td>
                <td>Harga</td>
                <td>Outlet</td>
                <td>Aksi</td>
            </tr>
        </thead>
        <?php
        $no = 1;
        foreach ($paket as $p) :
            if ($p->id_outlet) : ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $p->nama_paket; ?></td>
                    <td><?= $p->jenis; ?></td>
                    <td><?= $p->harga; ?></td>
                    <td><?= $p->nama_outlet; ?></td>
                    <td>
                        <a href="<?= base_url('C_Paket/formeditpaket/' . $p->id_paket) ?>" class="btn btn-primary">Edit</a>
                        <a href="<?= base_url('C_Paket/hapuspaket/' . $p->id_paket) ?>" onclick="return confirm('Yakin Hapus Data Paket?')" class="btn btn-danger">Hapus</a>
                    </td>
                </tr>
        <?php
            endif;
        endforeach
        ?>
    </table>
    <a href="<?= base_url('C_Paket/formtambahpaket') ?>" class="btn btn-success mt-3 mb-3">Tambah</a>
</div>