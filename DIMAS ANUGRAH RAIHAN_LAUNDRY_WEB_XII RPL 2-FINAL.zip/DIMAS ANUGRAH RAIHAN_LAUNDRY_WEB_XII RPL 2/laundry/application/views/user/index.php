<div class="container">
    <h3 class="text-center mt-3"><?= $judul; ?></h3>
    <?php if ($this->session->flashdata()) : ?>
        <div class="alert alert-success mt-3">
            <?= $this->session->flashdata('pesan'); ?>
        </div>
    <?php endif ?>
    <table class="table table-bordered mt-3" id="data">
        <thead class="bg-dark text-white">
            <tr>
                <td>No</td>
                <td>Nama</td>
                <td>Level</td>
                <td>Nama Outlet</td>
                <td>Aksi</td>
            </tr>
        </thead>
        <?php
        $no = 1;
        foreach ($user as $u) :
            if ($u->id_outlet) :
        ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $u->nama_user; ?></td>
                    <td><?= $u->level; ?></td>
                    <td><?= $u->nama_outlet; ?></td>
                    <td>
                        <a href="<?= base_url('C_User/formedituser/' . $u->id_user) ?>" class="btn btn-primary">Edit</a>
                        <a href="<?= base_url('C_User/hapususer/' . $u->id_user) ?>" onclick="return confirm('Yakin Hapus Data User?')" class="btn btn-danger">Hapus</a>
                        <a href="<?= base_url('C_User/resetpass/' . $u->id_user) ?>" onclick="return confirm('Password akan direset secara default menjadi random123 Apakah Anda Yakin?')" class="btn btn-warning">Reset Password</a>
                    </td>
                </tr>
            <?php endif ?>
        <?php endforeach ?>
    </table>
    <a href="<?= base_url('C_User/formtambahuser') ?>" class="btn btn-success mt-3 mb-3">Tambah</a>
</div>